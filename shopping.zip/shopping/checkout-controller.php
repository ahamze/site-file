<?php
include 'includes/session.php';

if (isset($_POST['checkout'])) {
    $_SESSION['checkout'] = 1;
} else {
    header('location:' . ROOT_HOST . 'cart');
}

header('location:' . ROOT_HOST  . 'checkout');
